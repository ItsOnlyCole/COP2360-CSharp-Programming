﻿//Cole Hemp
//Form1.Designer.cs
//Generates Form1

namespace PBSCTicketBooth
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.basketballMinusTicketButton = new System.Windows.Forms.Button();
            this.basketballPlusTicketsButton = new System.Windows.Forms.Button();
            this.basketballTicketsTextBox = new System.Windows.Forms.TextBox();
            this.musicalMinusTicketsButton = new System.Windows.Forms.Button();
            this.musicalTicketsTextBox = new System.Windows.Forms.TextBox();
            this.musicalPlusTicketsButton = new System.Windows.Forms.Button();
            this.playMinusTicketsButton = new System.Windows.Forms.Button();
            this.playTicketsTextBox = new System.Windows.Forms.TextBox();
            this.playPlusTicketsButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.ReserveButton = new System.Windows.Forms.Button();
            this.fillerBasketballLabel = new System.Windows.Forms.Label();
            this.basketballOpposingTeamLabel = new System.Windows.Forms.Label();
            this.basketballDateLabel = new System.Windows.Forms.Label();
            this.basketballTicketCostLabel = new System.Windows.Forms.Label();
            this.DollarSignLabel1 = new System.Windows.Forms.Label();
            this.DollarSignLabel2 = new System.Windows.Forms.Label();
            this.DollarSignLabel3 = new System.Windows.Forms.Label();
            this.musicalTicketCostLabel = new System.Windows.Forms.Label();
            this.playTicketCostLabel = new System.Windows.Forms.Label();
            this.musicalDateLabel = new System.Windows.Forms.Label();
            this.playDateLabel = new System.Windows.Forms.Label();
            this.musicalNameLabel = new System.Windows.Forms.Label();
            this.musicalFillerLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.musicalTheaterLabel = new System.Windows.Forms.Label();
            this.playNameLabel = new System.Windows.Forms.Label();
            this.playFillerLabel = new System.Windows.Forms.Label();
            this.playTheaterLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // basketballMinusTicketButton
            // 
            this.basketballMinusTicketButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.basketballMinusTicketButton.Location = new System.Drawing.Point(12, 41);
            this.basketballMinusTicketButton.Name = "basketballMinusTicketButton";
            this.basketballMinusTicketButton.Size = new System.Drawing.Size(47, 63);
            this.basketballMinusTicketButton.TabIndex = 0;
            this.basketballMinusTicketButton.Text = "-";
            this.basketballMinusTicketButton.UseVisualStyleBackColor = true;
            this.basketballMinusTicketButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // basketballPlusTicketsButton
            // 
            this.basketballPlusTicketsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.basketballPlusTicketsButton.Location = new System.Drawing.Point(223, 42);
            this.basketballPlusTicketsButton.Name = "basketballPlusTicketsButton";
            this.basketballPlusTicketsButton.Size = new System.Drawing.Size(47, 63);
            this.basketballPlusTicketsButton.TabIndex = 1;
            this.basketballPlusTicketsButton.Text = "+";
            this.basketballPlusTicketsButton.UseVisualStyleBackColor = true;
            this.basketballPlusTicketsButton.Click += new System.EventHandler(this.basketballPlusTicketsButton_Click);
            // 
            // basketballTicketsTextBox
            // 
            this.basketballTicketsTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.basketballTicketsTextBox.Location = new System.Drawing.Point(65, 42);
            this.basketballTicketsTextBox.Name = "basketballTicketsTextBox";
            this.basketballTicketsTextBox.Size = new System.Drawing.Size(152, 62);
            this.basketballTicketsTextBox.TabIndex = 2;
            this.basketballTicketsTextBox.Text = "0";
            this.basketballTicketsTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.basketballTicketsTextBox.WordWrap = false;
            // 
            // musicalMinusTicketsButton
            // 
            this.musicalMinusTicketsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.musicalMinusTicketsButton.Location = new System.Drawing.Point(12, 165);
            this.musicalMinusTicketsButton.Name = "musicalMinusTicketsButton";
            this.musicalMinusTicketsButton.Size = new System.Drawing.Size(47, 63);
            this.musicalMinusTicketsButton.TabIndex = 3;
            this.musicalMinusTicketsButton.Text = "-";
            this.musicalMinusTicketsButton.UseVisualStyleBackColor = true;
            this.musicalMinusTicketsButton.Click += new System.EventHandler(this.musicalMinusTicketsButton_Click);
            // 
            // musicalTicketsTextBox
            // 
            this.musicalTicketsTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.musicalTicketsTextBox.Location = new System.Drawing.Point(65, 166);
            this.musicalTicketsTextBox.Name = "musicalTicketsTextBox";
            this.musicalTicketsTextBox.Size = new System.Drawing.Size(152, 62);
            this.musicalTicketsTextBox.TabIndex = 4;
            this.musicalTicketsTextBox.Text = "0";
            this.musicalTicketsTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.musicalTicketsTextBox.WordWrap = false;
            // 
            // musicalPlusTicketsButton
            // 
            this.musicalPlusTicketsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.musicalPlusTicketsButton.Location = new System.Drawing.Point(223, 165);
            this.musicalPlusTicketsButton.Name = "musicalPlusTicketsButton";
            this.musicalPlusTicketsButton.Size = new System.Drawing.Size(47, 63);
            this.musicalPlusTicketsButton.TabIndex = 5;
            this.musicalPlusTicketsButton.Text = "+";
            this.musicalPlusTicketsButton.UseVisualStyleBackColor = true;
            this.musicalPlusTicketsButton.Click += new System.EventHandler(this.musicalPlusTicketsButton_Click);
            // 
            // playMinusTicketsButton
            // 
            this.playMinusTicketsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playMinusTicketsButton.Location = new System.Drawing.Point(12, 293);
            this.playMinusTicketsButton.Name = "playMinusTicketsButton";
            this.playMinusTicketsButton.Size = new System.Drawing.Size(47, 63);
            this.playMinusTicketsButton.TabIndex = 6;
            this.playMinusTicketsButton.Text = "-";
            this.playMinusTicketsButton.UseVisualStyleBackColor = true;
            this.playMinusTicketsButton.Click += new System.EventHandler(this.playMinusTicketsButton_Click);
            // 
            // playTicketsTextBox
            // 
            this.playTicketsTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playTicketsTextBox.Location = new System.Drawing.Point(65, 293);
            this.playTicketsTextBox.Name = "playTicketsTextBox";
            this.playTicketsTextBox.Size = new System.Drawing.Size(152, 62);
            this.playTicketsTextBox.TabIndex = 7;
            this.playTicketsTextBox.Text = "0";
            this.playTicketsTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.playTicketsTextBox.WordWrap = false;
            // 
            // playPlusTicketsButton
            // 
            this.playPlusTicketsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playPlusTicketsButton.Location = new System.Drawing.Point(223, 293);
            this.playPlusTicketsButton.Name = "playPlusTicketsButton";
            this.playPlusTicketsButton.Size = new System.Drawing.Size(47, 63);
            this.playPlusTicketsButton.TabIndex = 8;
            this.playPlusTicketsButton.Text = "+";
            this.playPlusTicketsButton.UseVisualStyleBackColor = true;
            this.playPlusTicketsButton.Click += new System.EventHandler(this.playPlusTicketsButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelButton.Location = new System.Drawing.Point(12, 418);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(204, 67);
            this.CancelButton.TabIndex = 9;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // ReserveButton
            // 
            this.ReserveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 33.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReserveButton.Location = new System.Drawing.Point(429, 418);
            this.ReserveButton.Name = "ReserveButton";
            this.ReserveButton.Size = new System.Drawing.Size(204, 67);
            this.ReserveButton.TabIndex = 10;
            this.ReserveButton.Text = "Reserve";
            this.ReserveButton.UseVisualStyleBackColor = true;
            this.ReserveButton.Click += new System.EventHandler(this.ReserveButton_Click);
            // 
            // fillerBasketballLabel
            // 
            this.fillerBasketballLabel.AutoSize = true;
            this.fillerBasketballLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fillerBasketballLabel.Location = new System.Drawing.Point(280, 42);
            this.fillerBasketballLabel.Name = "fillerBasketballLabel";
            this.fillerBasketballLabel.Size = new System.Drawing.Size(287, 29);
            this.fillerBasketballLabel.TabIndex = 11;
            this.fillerBasketballLabel.Text = "Basketball Game Against:";
            // 
            // basketballOpposingTeamLabel
            // 
            this.basketballOpposingTeamLabel.AutoSize = true;
            this.basketballOpposingTeamLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.basketballOpposingTeamLabel.Location = new System.Drawing.Point(573, 42);
            this.basketballOpposingTeamLabel.Name = "basketballOpposingTeamLabel";
            this.basketballOpposingTeamLabel.Size = new System.Drawing.Size(60, 29);
            this.basketballOpposingTeamLabel.TabIndex = 12;
            this.basketballOpposingTeamLabel.Text = "FAU";
            // 
            // basketballDateLabel
            // 
            this.basketballDateLabel.AutoSize = true;
            this.basketballDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.basketballDateLabel.Location = new System.Drawing.Point(280, 76);
            this.basketballDateLabel.Name = "basketballDateLabel";
            this.basketballDateLabel.Size = new System.Drawing.Size(239, 29);
            this.basketballDateLabel.TabIndex = 13;
            this.basketballDateLabel.Text = "4/26/18          7:00 PM";
            // 
            // basketballTicketCostLabel
            // 
            this.basketballTicketCostLabel.AutoSize = true;
            this.basketballTicketCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.basketballTicketCostLabel.Location = new System.Drawing.Point(110, 107);
            this.basketballTicketCostLabel.Name = "basketballTicketCostLabel";
            this.basketballTicketCostLabel.Size = new System.Drawing.Size(26, 29);
            this.basketballTicketCostLabel.TabIndex = 15;
            this.basketballTicketCostLabel.Text = "0";
            this.basketballTicketCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DollarSignLabel1
            // 
            this.DollarSignLabel1.AutoSize = true;
            this.DollarSignLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DollarSignLabel1.Location = new System.Drawing.Point(78, 107);
            this.DollarSignLabel1.Name = "DollarSignLabel1";
            this.DollarSignLabel1.Size = new System.Drawing.Size(26, 29);
            this.DollarSignLabel1.TabIndex = 16;
            this.DollarSignLabel1.Text = "$";
            // 
            // DollarSignLabel2
            // 
            this.DollarSignLabel2.AutoSize = true;
            this.DollarSignLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DollarSignLabel2.Location = new System.Drawing.Point(78, 231);
            this.DollarSignLabel2.Name = "DollarSignLabel2";
            this.DollarSignLabel2.Size = new System.Drawing.Size(26, 29);
            this.DollarSignLabel2.TabIndex = 17;
            this.DollarSignLabel2.Text = "$";
            // 
            // DollarSignLabel3
            // 
            this.DollarSignLabel3.AutoSize = true;
            this.DollarSignLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DollarSignLabel3.Location = new System.Drawing.Point(78, 358);
            this.DollarSignLabel3.Name = "DollarSignLabel3";
            this.DollarSignLabel3.Size = new System.Drawing.Size(26, 29);
            this.DollarSignLabel3.TabIndex = 18;
            this.DollarSignLabel3.Text = "$";
            // 
            // musicalTicketCostLabel
            // 
            this.musicalTicketCostLabel.AutoSize = true;
            this.musicalTicketCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.musicalTicketCostLabel.Location = new System.Drawing.Point(110, 231);
            this.musicalTicketCostLabel.Name = "musicalTicketCostLabel";
            this.musicalTicketCostLabel.Size = new System.Drawing.Size(26, 29);
            this.musicalTicketCostLabel.TabIndex = 19;
            this.musicalTicketCostLabel.Text = "0";
            this.musicalTicketCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // playTicketCostLabel
            // 
            this.playTicketCostLabel.AutoSize = true;
            this.playTicketCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playTicketCostLabel.Location = new System.Drawing.Point(110, 358);
            this.playTicketCostLabel.Name = "playTicketCostLabel";
            this.playTicketCostLabel.Size = new System.Drawing.Size(26, 29);
            this.playTicketCostLabel.TabIndex = 20;
            this.playTicketCostLabel.Text = "0";
            this.playTicketCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // musicalDateLabel
            // 
            this.musicalDateLabel.AutoSize = true;
            this.musicalDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.musicalDateLabel.Location = new System.Drawing.Point(280, 199);
            this.musicalDateLabel.Name = "musicalDateLabel";
            this.musicalDateLabel.Size = new System.Drawing.Size(239, 29);
            this.musicalDateLabel.TabIndex = 21;
            this.musicalDateLabel.Text = "4/24/18          9:00 PM";
            // 
            // playDateLabel
            // 
            this.playDateLabel.AutoSize = true;
            this.playDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playDateLabel.Location = new System.Drawing.Point(280, 327);
            this.playDateLabel.Name = "playDateLabel";
            this.playDateLabel.Size = new System.Drawing.Size(239, 29);
            this.playDateLabel.TabIndex = 22;
            this.playDateLabel.Text = "4/29/18          5:00 PM";
            // 
            // musicalNameLabel
            // 
            this.musicalNameLabel.AutoSize = true;
            this.musicalNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.musicalNameLabel.Location = new System.Drawing.Point(285, 165);
            this.musicalNameLabel.Name = "musicalNameLabel";
            this.musicalNameLabel.Size = new System.Drawing.Size(149, 29);
            this.musicalNameLabel.TabIndex = 25;
            this.musicalNameLabel.Text = "Wizard of Oz";
            // 
            // musicalFillerLabel
            // 
            this.musicalFillerLabel.AutoSize = true;
            this.musicalFillerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.musicalFillerLabel.Location = new System.Drawing.Point(456, 166);
            this.musicalFillerLabel.Name = "musicalFillerLabel";
            this.musicalFillerLabel.Size = new System.Drawing.Size(34, 29);
            this.musicalFillerLabel.TabIndex = 26;
            this.musicalFillerLabel.Text = "At";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "label2";
            // 
            // musicalTheaterLabel
            // 
            this.musicalTheaterLabel.AutoSize = true;
            this.musicalTheaterLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.musicalTheaterLabel.Location = new System.Drawing.Point(511, 166);
            this.musicalTheaterLabel.Name = "musicalTheaterLabel";
            this.musicalTheaterLabel.Size = new System.Drawing.Size(94, 29);
            this.musicalTheaterLabel.TabIndex = 28;
            this.musicalTheaterLabel.Text = "Duncan";
            // 
            // playNameLabel
            // 
            this.playNameLabel.AutoSize = true;
            this.playNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playNameLabel.Location = new System.Drawing.Point(276, 293);
            this.playNameLabel.Name = "playNameLabel";
            this.playNameLabel.Size = new System.Drawing.Size(193, 29);
            this.playNameLabel.TabIndex = 29;
            this.playNameLabel.Text = "The Odd Couple";
            // 
            // playFillerLabel
            // 
            this.playFillerLabel.AutoSize = true;
            this.playFillerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playFillerLabel.Location = new System.Drawing.Point(471, 293);
            this.playFillerLabel.Name = "playFillerLabel";
            this.playFillerLabel.Size = new System.Drawing.Size(34, 29);
            this.playFillerLabel.TabIndex = 30;
            this.playFillerLabel.Text = "At";
            // 
            // playTheaterLabel
            // 
            this.playTheaterLabel.AutoSize = true;
            this.playTheaterLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playTheaterLabel.Location = new System.Drawing.Point(511, 293);
            this.playTheaterLabel.Name = "playTheaterLabel";
            this.playTheaterLabel.Size = new System.Drawing.Size(94, 29);
            this.playTheaterLabel.TabIndex = 31;
            this.playTheaterLabel.Text = "Duncan";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(651, 506);
            this.Controls.Add(this.playTheaterLabel);
            this.Controls.Add(this.playFillerLabel);
            this.Controls.Add(this.playNameLabel);
            this.Controls.Add(this.musicalTheaterLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.musicalFillerLabel);
            this.Controls.Add(this.musicalNameLabel);
            this.Controls.Add(this.playDateLabel);
            this.Controls.Add(this.musicalDateLabel);
            this.Controls.Add(this.playTicketCostLabel);
            this.Controls.Add(this.musicalTicketCostLabel);
            this.Controls.Add(this.DollarSignLabel3);
            this.Controls.Add(this.DollarSignLabel2);
            this.Controls.Add(this.DollarSignLabel1);
            this.Controls.Add(this.basketballTicketCostLabel);
            this.Controls.Add(this.basketballDateLabel);
            this.Controls.Add(this.basketballOpposingTeamLabel);
            this.Controls.Add(this.fillerBasketballLabel);
            this.Controls.Add(this.ReserveButton);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.playPlusTicketsButton);
            this.Controls.Add(this.playTicketsTextBox);
            this.Controls.Add(this.playMinusTicketsButton);
            this.Controls.Add(this.musicalPlusTicketsButton);
            this.Controls.Add(this.musicalTicketsTextBox);
            this.Controls.Add(this.musicalMinusTicketsButton);
            this.Controls.Add(this.basketballTicketsTextBox);
            this.Controls.Add(this.basketballPlusTicketsButton);
            this.Controls.Add(this.basketballMinusTicketButton);
            this.Name = "Form1";
            this.Text = "Ticket Reservations";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button basketballMinusTicketButton;
        private System.Windows.Forms.Button basketballPlusTicketsButton;
        private System.Windows.Forms.TextBox basketballTicketsTextBox;
        private System.Windows.Forms.Button musicalMinusTicketsButton;
        private System.Windows.Forms.TextBox musicalTicketsTextBox;
        private System.Windows.Forms.Button musicalPlusTicketsButton;
        private System.Windows.Forms.Button playMinusTicketsButton;
        private System.Windows.Forms.TextBox playTicketsTextBox;
        private System.Windows.Forms.Button playPlusTicketsButton;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Button ReserveButton;
        private System.Windows.Forms.Label fillerBasketballLabel;
        private System.Windows.Forms.Label basketballOpposingTeamLabel;
        private System.Windows.Forms.Label basketballDateLabel;
        private System.Windows.Forms.Label basketballTicketCostLabel;
        private System.Windows.Forms.Label DollarSignLabel1;
        private System.Windows.Forms.Label DollarSignLabel2;
        private System.Windows.Forms.Label DollarSignLabel3;
        private System.Windows.Forms.Label musicalTicketCostLabel;
        private System.Windows.Forms.Label playTicketCostLabel;
        private System.Windows.Forms.Label musicalDateLabel;
        private System.Windows.Forms.Label playDateLabel;
        private System.Windows.Forms.Label musicalNameLabel;
        private System.Windows.Forms.Label musicalFillerLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label musicalTheaterLabel;
        private System.Windows.Forms.Label playNameLabel;
        private System.Windows.Forms.Label playFillerLabel;
        private System.Windows.Forms.Label playTheaterLabel;
    }
}

